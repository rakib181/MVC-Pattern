<?php

function valid_name($name){
      $name = trim($name);
      return strlen($name) > 2 && strlen($name) < 20;
}

function valid_email($email){
    $email = trim($email);
    return filter_var($email, FILTER_VALIDATE_EMAIL);
}

function valid_password($password){
    $password = trim($password);
    return strlen($password) > 4 && strlen($password) < 15;
}

function valid_role($role){
    $role = trim($role);
    return $role === "admin" || $role === "user";
}

function valid_title_and_description($title_or_description){
    $title_or_description = trim($title_or_description);
    return strlen($title_or_description) > 2 && strlen($title_or_description) < 50;
}