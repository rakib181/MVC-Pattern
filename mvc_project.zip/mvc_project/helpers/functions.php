<?php
function route($name, $params = []) {
    global $router;
    return $router->getRouteByName($name, $params);
}

function redirect($url) {
    header("Location: " . $url);
    exit();
}

function dd($value){
    echo "<pre>";
    var_dump($value);
    echo "</pre>";
    die();
}

function pr($value){
    echo "<pre>";
    print_r($value);
    echo "</pre>";
}

function prdd($value){
    echo "<pre>";
    print_r($value);
    echo "</pre>";
    die();
}

function dump($value){
    echo "<pre>";
    var_dump($value);
    echo "</pre>";
}