// Basic JavaScript
console.log("Script loaded.");