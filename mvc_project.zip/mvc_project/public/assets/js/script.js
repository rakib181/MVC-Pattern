// Basic JavaScript
function ajaxCall(
    callParams,
    successCallback,
    errorCallback,
    timeout = 200000,
    quietMillis = 100
) 
{
    let ajaxOption = {
        url: callParams.url,
        timeout: timeout,
        type: callParams.type || "POST", // "POST" OR "GET
        dataType: callParams.dataType || "JSON",
        data: callParams.data || {},
        cache: callParams.cache || false,
        processData: callParams.processData || false,
        contentType: callParams.contentType || false,
        complete: callParams.complete || function () {},
        success: successCallback,
        error: errorCallback,
    };

    if (!callParams.hasOwnProperty("processData")) {
        delete ajaxOption.processData;
    }
    if (!callParams.hasOwnProperty("contentType")) {
        delete ajaxOption.contentType;
    }

    if (!callParams.hasOwnProperty("cache")) {
        delete ajaxOption.cache;
    }

    if (!callParams.hasOwnProperty("complete")) {
        delete ajaxOption.complete;
    }

    $.ajax(ajaxOption);
}

