<?php

define('BASE_URL', '/php/mvc_project'); // Adjust if needed

define('DB_HOST', 'localhost:8889');
define('DB_USER', 'root');
define('DB_PASS', 'root');
define('DB_NAME', 'writerap');