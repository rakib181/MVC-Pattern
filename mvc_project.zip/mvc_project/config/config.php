<?php

define('BASE_URL', '/mvc_project'); // Adjust if needed
define('ROOT', '/mvc_project/public'); // Adjust if needed

define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'task management system');