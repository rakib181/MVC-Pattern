<?php

use App\Controllers\HomeController;
use App\Controllers\UserController;

Router::get('/home', [HomeController::class, 'index']);

// listing
Router::get('/users', [UserController::class, 'index'])->name("users.index");

// Add
Router::get('/users/create', [UserController::class, 'create'])->name("users.create");
Router::post('/users', [UserController::class, 'store'])->name("users.store");

// Edit
Router::get('/users/{id}/edit', [UserController::class, 'edit'])->name("users.edit");
Router::post('/users/{id}', [UserController::class, 'update'])->name("users.update");

// delete
Router::get('/users/{id}/delete', [UserController::class, 'delete'])->name("users.delete");