<?php

use App\Controllers\LoginController;
use App\Controllers\RegistrationController;
use App\Controllers\UserController;
use App\Controllers\AdminController;


Router::get('/login', [LoginController::class, 'index'])->name('login.index');
Router::post('/login/cred', [LoginController::class, 'cred'])->name('login.cred');

Router::get('/register', [RegistrationController::class, 'index']);
Router::post('/register', [RegistrationController::class, 'create'])->name('register.create');

Router::get('/admins/dashboard', [AdminController::class, 'index']);
Router::get('/admins/loadAllTasks', [AdminController::class, 'loadTask'])->name('admins.load');
Router::post('/admins/{id}/delete', [AdminController::class, 'delete'])->name('task.delete');
Router::get('/admins/taskCreate', [AdminController::class, 'create']);
Router::post('/admins/create', [AdminController::class, 'createTask'])->name('task.create');
Router::get('/admins/editload', [AdminController::class, 'edit'])->name('task.editload');
Router::get('/admins/loadTask', [AdminController::class, 'taskEditLoad'])->name('edit.load');
Router::post('/admins/edit', [AdminController::class, 'edited'])->name('task.edit');
Router::get('/admins/assignload', [AdminController::class, 'assign'])->name('task.assignload');
Router::post('/admins/assign', [AdminController::class, 'assignTask'])->name('assign.task');
Router::post('/admins/report', [AdminController::class, 'report'])->name('task.report');

Router::get('/users/dashboard', [UserController::class, 'index']);
Router::post('/users/{id}', [UserController::class, 'loadUser'])->name('user.load');
Router::post('/users/{id}/loadStatus', [UserController::class, 'loadStatus'])->name('user.status');
Router::post('/users/{id}/update', [UserController::class, 'update'])->name('user.update');