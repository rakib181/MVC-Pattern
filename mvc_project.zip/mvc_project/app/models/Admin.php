<?php

namespace App\Models;

use Core\Model;

class Admin extends Model
{
    public function getTaskById($id)
    {
        $sql = "SELECT * FROM tasks WHERE id = ?";
        $stmt = $this->db->prepare($sql);
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $result = $stmt->get_result();
        return $result->fetch_assoc();
    }
    public function editTaskByID($id, $title, $description, $due_date, $priority)
    {
        $sql = "UPDATE tasks SET title = ?, description = ?, due_date = ?, priority = ? WHERE id =?";
        $stmt = $this->db->prepare($sql);
        $stmt->bind_param("ssssi", $title, $description, $due_date, $priority, $id);
        return $stmt->execute();
    }
    public function getAllUsers()
    {
        $sql = "SELECT * FROM users WHERE role='user'";
        $stmt = $this->db->prepare($sql);
        $stmt->execute();
        $result = $stmt->get_result();
        return $result;
    }

    public function getTaskReport()
    {
        $sql = "SELECT * FROM tasks WHERE status = 'pending' OR status = 'completed'";
        $result = $this->db->query($sql);
        return $result->fetch_all(MYSQLI_ASSOC);
    }

    public function assignTask($userId, $taskId)
    {
        $sql = "UPDATE tasks SET assigned_to = $userId WHERE id = $taskId";
        $stmt = $this->db->prepare($sql);
        return $stmt->execute();
    }
    public function getAllTasks()
    {
        $sql = "SELECT * FROM tasks";
        $stmt = $this->db->prepare($sql);
        $stmt->execute();
        return $stmt->get_result();
    }
    public function delete($id)
    {
        $sql = "DELETE FROM tasks WHERE id = ?";
        $stmt = $this->db->prepare($sql);
        $stmt->bind_param("i", $id);
        return $stmt->execute();
    }
    public function createTask($title, $description, $due_date, $priority)
    {
        $sql = "INSERT INTO tasks(title, description, due_date, priority) VALUES(?, ?, ?, ?)";
        $stmt = $this->db->prepare($sql);
        $stmt->bind_param("ssss", $title, $description, $due_date, $priority);
        return $stmt->execute();
    }
}
