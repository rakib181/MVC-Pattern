<?php

namespace App\Models;

use Core\Model;

class User extends Model {
    public function getTaskById($id) {
        $sql = "SELECT * FROM tasks WHERE assigned_to = ?";
        $stmt = $this->db->prepare($sql);
        $stmt->bind_param("i", $id);
        $stmt->execute();
        return $stmt->get_result();
    }
    public function update($id, $status){
        $sql = 'UPDATE tasks SET status=? WHERE id=?';
        $stmt = $this->db->prepare($sql);
        $stmt->bind_param("si", $status, $id);
        return $stmt->execute();
    }
}