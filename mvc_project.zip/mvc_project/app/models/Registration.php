<?php

namespace App\Models;

use Core\Model;

class Registration extends Model {
    public function create($name, $email, $password, $role) {
        $sql = "INSERT INTO users(name, email, password, role) VALUES(?, ?, ?, ?)";
        $stmt = $this->db->prepare($sql);
        $stmt->bind_param("ssss", $name, $email, $password, $role);
        return $stmt->execute();
    }
    public function getUserByEmail($email){
        $sql = "SELECT * FROM users WHERE email=?";
        $stmt = $this->db->prepare($sql);
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();
        return $result->fetch_assoc();
    }
}