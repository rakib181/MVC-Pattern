<?php
namespace App\Services;
use App\Models\Login;
class LoginService{
    protected $loginModal;

    public function __construct(){
        $this->loginModal = new Login();
    }

    public function getUserByEmailAndPassword($email, $password){
        return $this->loginModal->getUserByEmailAndPassword($email, $password);
    }
}