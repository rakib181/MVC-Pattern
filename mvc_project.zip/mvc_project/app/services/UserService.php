<?php

namespace App\Services;

use App\Models\User;

class UserService {
    protected $userModel;

    public function __construct() {
        $this->userModel = new User();
    }

    public function getAllUsers() {
        return $this->userModel->getAllUsers();
    }

    public function getUserById($id) {
        return $this->userModel->getUserById($id);
    }

    public function createUser($name, $email) {
        return $this->userModel->createUser($name, $email);
    }

    public function updateUser($id, $name, $email) {
        return $this->userModel->updateUser($id, $name, $email);
    }

    public function deleteUser($id) {
        return $this->userModel->deleteUser($id);
    }
}