<?php
namespace App\Services;
use App\Models\User;
class UserService{
    protected $userModal;

    public function __construct(){
        $this->userModal = new User();
    }

    public function getTaskbyId($id){
        return $this->userModal->getTaskbyId($id);
    }
    public function update($id, $status){
        return $this->userModal->update($id, $status);
    }
}