<?php
namespace App\Services;
use App\Models\Admin;
class AdminService{
    protected $adminModal;

    public function __construct(){
        $this->adminModal = new Admin();
    }

    public function getAllTasks(){
        return $this->adminModal->getAllTasks();
    }
    public function getTaskReport(){
        return $this->adminModal->getTaskReport();
    }
    public function getAllUsers(){
        return $this->adminModal->getAllUsers();
    }
    public function assignTask($userId, $taskId){
        return $this->adminModal->assignTask($userId, $taskId);
    }
    public function delete($id){
        return $this->adminModal->delete($id);
    }
    public function createTask($title, $description, $due_date, $priority){
        return $this->adminModal->createTask($title, $description, $due_date, $priority);
    }
    public function getTaskById($id){
        return $this->adminModal->getTaskById($id);
    }
    public function editTaskByID($id, $title, $description, $due_date, $priority){
        return $this->adminModal->editTaskByID($id, $title, $description, $due_date, $priority);
    }
}