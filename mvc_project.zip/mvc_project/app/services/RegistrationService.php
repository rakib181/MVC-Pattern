<?php
namespace App\Services;
use App\Models\Login;
use App\Models\Registration;
class RegistrationService{
    protected $registerModal;

    public function __construct(){
        $this->registerModal = new Registration();
    }

    public function create($name, $email, $password, $role){
        return $this->registerModal->create($name, $email, $password, $role);
    }
    public function getUserByEmail($email){
        return $this->registerModal->getUserByEmail($email);
    }
}