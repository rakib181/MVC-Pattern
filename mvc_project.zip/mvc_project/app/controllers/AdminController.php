<?php
namespace App\Controllers;
require_once __DIR__.'/../../helpers/validation.php';

use App\Services\AdminService;
use Core\Controller;

class AdminController extends Controller{
    protected $adminService;

    public function __construct(){
        $this->adminService = new AdminService();
    }
    public function index(){
        $tasks = $this->adminService->getAllTasks();
        return $this->view('admins/dashboard', ['title' => 'Task Management System', "tasks" => $tasks]);
    }
    public function loadTask(){
        $tasks = $this->adminService->getAllTasks();
        $response = [
            "status" => false,
            "message" => $this->view('admins/loadTasks', ['tasks' => $tasks], true),
        ];
        echo json_encode($response);
    }
    public function delete(){
        $taskId = $_POST['id'];
        $response = [
            "status" => false,
            "message" => "",
        ];
        if($this->adminService->delete($taskId)){
            $response['status'] = true;
            $response['message'] = 'Successfully Deleted Task.';
        }else{
            $response['status'] = false;
            $response['message'] = 'Something went wrong.';
        }
        echo json_encode($response);
    }

    public function edit(){
        $this->view('admins/edit', ["id" => $_GET['id']]);
    }
    public function assign(){
        $users = $this->adminService->getAllUsers();
        $this->view('admins/assign', ["id" => $_GET['id'], "users" => $users]);
    }

    public function report(){
        $taskReport = $this->adminService->getTaskReport();
        $response = [
            "status" => false,
            "message" => $this->view('/admins/loadReport', ["tasks" => $taskReport], true),
        ];
        echo json_encode($response);
    }

    public function assignTask(){
        $response = [
           "status" => true,
           "message" => "",
        ];
        $userId = $_POST['userId'];
        $taskId = $_POST['taskId'];
        if(empty($userId)){
            $response['status'] = false;
            $response['message'] = 'Select an user please.';
        }
        if(!$response['status']){
            echo json_encode($response);
            exit;
        }
        if($this->adminService->assignTask($userId, $taskId)){
            $response['status'] = true;
            $response['message'] = 'Successfully assigned task.';
        }else{
            $response['status'] = false;
            $response['message'] = 'Something went wrong.';
        }
        echo json_encode($response);
    }

    public function edited(){
        $response = [
            "status" => true,
            "message" => "",
          ];
          $id = $_POST['id'];
          $title = $_POST['title'];
          $description = $_POST['description'];
          $due_date = $_POST['due_date'];
          $priority = $_POST['priority'];
          if(!valid_title_and_description($title)){
             $response['status'] = false;
             $response['message'] = 'Invalid title or description.';
          }
          if(!$response['status']){
           echo json_encode($response);
           exit;
          }
          if(!valid_title_and_description($description)){
           $response['status'] = false;
           $response['message'] = 'Invalid title or description.';
        }
        if(!$response['status']){
         echo json_encode($response);
         exit;
        }
        if($this->adminService->editTaskByID($id, $title, $description, $due_date, $priority)){
           $response['status'] = true;
           $response['message'] = 'Successfully updated a task.';
       }else{
          $response['status'] = false;
          $response['message'] = 'Something went wrong.';
       }
        echo json_encode($response);
    }

    public function taskEditLoad(){
        $task = $this->adminService->getTaskById($_GET['id']);
        $response = [
            "message" => $this->view('admins/loadTask', ["task" => $task], true),
        ];
        echo json_encode($response);
    }
    public function create(){
        $this->view('/admins/create');
    }
    public function createTask() {
       $response = [
         "status" => true,
         "message" => "",
       ];
       $title = $_POST['title'];
       $description = $_POST['description'];
       $due_date = $_POST['due_date'];
       $priority = $_POST['priority'];
       if(!valid_title_and_description($title)){
          $response['status'] = false;
          $response['message'] = 'Invalid title or description.';
       }
       if(!$response['status']){
        echo json_encode($response);
        exit;
       }
       if(!valid_title_and_description($description)){
        $response['status'] = false;
        $response['message'] = 'Invalid title or description.';
     }
     if(!$response['status']){
      echo json_encode($response);
      exit;
     }
     if($this->adminService->createTask($title, $description, $due_date, $priority)){
        $response['status'] = true;
        $response['message'] = 'Successfully created a task.';
    }else{
       $response['status'] = false;
       $response['message'] = 'Something went wrong.';
    }
     echo json_encode($response);
    }
}