<?php
namespace App\Controllers;
use App\Services\LoginService;
use Core\Controller;

class LoginController extends Controller{
    protected $loginService;

    public function __construct(){
        $this->loginService = new LoginService();
    }
    public function index(){
        return $this->view('login', ['title' => 'Login Page']);
    }
    public function cred(){
        $response = [
            "status" => false,
            "message" => "",
        ];
        $result = $this->loginService->getUserByEmailAndPassword($_POST['email'], $_POST['password']);
        if($result){
            $response['status'] = true;
            $response['message'] = $result;
        }
        echo json_encode($response);
    }
    public function logout(){
        redirect(BASE_URL.'/login');
    }
}