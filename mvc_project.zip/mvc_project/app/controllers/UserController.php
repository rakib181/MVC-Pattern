<?php

namespace App\Controllers;

use Core\Controller;
use App\Services\UserService;

class UserController extends Controller {
    protected $userService;

    public function __construct() {
        $this->userService = new UserService();
    }

    public function index() {
        $users = $this->userService->getAllUsers();

        
        $this->view('user/index', ['users' => $users, 'title' => 'Users']);
    }

    public function create() {
        $this->view('user/create', ['title' => 'Create User']);
    }

    public function store() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $name = $_POST['name'];
            $email = $_POST['email'];
            if ($this->userService->createUser($name, $email)) {
                redirect(BASE_URL . "/users"); // Use redirect()
            } else {
                echo "Error creating user.";
            }
        }
    }

    public function edit($id) {
        $user = $this->userService->getUserById($id);
        if ($user) {
            $this->view('user/edit', ['user' => $user, 'title' => 'Edit User']);
        } else {
            echo "User not found.";
        }
    }

    public function update($id) {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $name = $_POST['name'];
            $email = $_POST['email'];
            if ($this->userService->updateUser($id, $name, $email)) {
                redirect(BASE_URL . "/users"); // Use redirect()
            } else {
                echo "Error updating user.";
            }
        }
    }

    public function delete($id) {
        if ($this->userService->deleteUser($id)) {
            redirect(BASE_URL . "/users"); // Use redirect()
        } else {
            echo "Error deleting user.";
        }
    }
}