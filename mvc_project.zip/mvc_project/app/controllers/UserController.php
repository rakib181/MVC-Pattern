<?php
namespace App\Controllers;
use App\Services\userService;
use Core\Controller;

class UserController extends Controller{
    protected $userService;

    public function __construct(){
        $this->userService = new UserService();
    }
    public function index(){
        return $this->view('users/dashboard', ['title' => 'User Page']);
    }
    public function loadUser($id){
        $tasks = $this->userService->getTaskbyId($id);
        $response = [
            "status"  => true,
            "message" => "Successfully loaded the tasks",
            "data"    => $this->view('users/loadUser', ['tasks' => $tasks], true),
        ];
        echo json_encode($response);
    }
    public function loadStatus($id){
        $tasks = $this->userService->getTaskbyId($id);
        $response = [
            "status"  => true,
            "message" => "Successfully loaded the  task status",
            "data"    => $this->view('users/loadUpdateStatus', ['tasks' => $tasks], true),
        ];
        echo json_encode($response);
    }
    public function update($id){
        $response = [
            "status" => true,
            "message" => "",
        ];
        $status = $_POST['status'];
        if($this->userService->update($id, $status)){
            $response['status'] = true;
            $response['message'] = 'Successfully Updated Task';
        }else{
            $response['status'] = false;
            $response['message'] = 'Something went wrong.';
        }
        echo json_encode($response);
    }
    
}