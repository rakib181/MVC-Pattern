<?php
namespace App\Controllers;
use App\Services\RegistrationService;
use Core\Controller;

require_once __DIR__.'/../../helpers/validation.php';

class RegistrationController extends Controller{
    protected $registerService;

    public function __construct(){
        $this->registerService = new RegistrationService();
    }
    public function index(){
        return $this->view('registration', ['title' => 'Registration Page']);
    }      
    public function create(){
        $name = !empty($_POST['name']) ? $_POST['name'] : '';
        $email = !empty($_POST['email']) ? $_POST['email'] : '';
        $password = !empty($_POST['password']) ? $_POST['password'] : '';
        $role = !empty($_POST['role']) ? $_POST['role'] : '';
        $response = [
            "status" => true,
            "message" => "",
        ];
        if(!valid_name($name)){
            $response['status'] = false;
            $response['message'] = 'Invalid name.';
        }
        if(!$response['status']){
            echo json_encode($response);
            exit;
        }
        if(!valid_email($email)){
            $response['status'] = false;
            $response['message'] = 'Invalid email.';
        }
        if(!$response['status']){
            echo json_encode($response);
            exit;
        }

        if(!valid_password($password)){
            $response['status'] = false;
            $response['message'] = 'Invalid password.';
        }
        if(!$response['status']){
            echo json_encode($response);
            exit;
        }

        if(!valid_role($role)){
            $response['status'] = false;
            $response['message'] = 'Invalid role.';
        }
        if(!$response['status']){
            echo json_encode($response);
            exit;
        }
        if($this->registerService->getUserByEmail($email)){
            $response['status'] = false;
            $response['message'] = 'Duplicate Email Address.';
        }else{
            $this->registerService->create($name, $email, $password, $role);
            $response['status'] = true;
            $response['message'] = 'Successfully Created.';
        }
        echo json_encode($response);
    }
}