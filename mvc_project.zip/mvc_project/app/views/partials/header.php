<!DOCTYPE html>
<html>
<head>
    <title><?php echo isset($title) ? $title : 'My MVC Project' ?></title>
    <link rel="stylesheet" href="<?php echo BASE_URL; ?>/assets/css/style.css">
</head>
<body>