<script src="<?php echo BASE_URL; ?>/assets/js/script.js"></script>
</body>
</html>