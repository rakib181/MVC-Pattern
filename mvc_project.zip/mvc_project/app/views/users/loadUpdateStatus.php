<?php
if(!empty($tasks)){
    echo "<select class='p-2 border round-1' name='selectTaskId'>";
    echo "<option>Select a task id</option>";
    foreach($tasks as $key => $value) {
        echo "<option>".$value['id']."</option>";
    }
    echo "</select>";
    echo "<select class='p-2 ms-2 border round-1' name='selectProgress'>
        <option class='text text-danger'>pending</option>
        <option class='text text-info'>in progress</option>
        <option class='text text-success'>completed</option>
    </select>";
    echo "<button class='ms-2 p-2 btn btn-primary' id='updateStatus'>Update</button>";
}else{
    echo "<tr>
    <td colspan='6' class='text text-danger text-center'>No task found for this user!</td></tr>";
}