<?php
if(!empty($tasks)){
    foreach($tasks as $key => $value) {
        echo "<tr>";
        echo "<td>".$value['id']."</td>";
        echo "<td>".$value["title"]."</td>";
        echo "<td>".$value["description"]."</td>";
        echo "<td>".$value["due_date"]."</td>";
        echo "<td>".$value["priority"]."</td>";
        echo "<td class='text ".(($value['status'] === "pending") ? 'text-danger' : (($value['status'] === 'in progress') ? 'text-info' : 'text-success'))."'>".$value["status"]."</td>";
        echo "</tr>";
    }
}else{
    echo "<tr>
    <td colspan='6' class='text text-danger text-center'>No task found for this user!</td></tr>";
}

