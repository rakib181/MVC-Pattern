<?php
require_once __DIR__ . '/../partials/header.php';
?>
<div class="container border mt-5">
    <div class="message d-none">
        <div class="alert"></div>
    </div>
    <h1 class="text text-info text-center">Task of ID = <?php echo $_GET['id']; ?></h1>
    <table class="table border">
        <thead>
            <tr>
                <th scope="col">ID</th>
                <th scope="col">TITLE</th>
                <th scope="col">DESCRIPTION</th>
                <th scope="col">DUE DATE</th>
                <th scope="col">PRIORITY</th>
                <th scope="col">STATUS</th>
            </tr>
        </thead>
        <tbody>

        </tbody>
    </table>
    <div class="status border p-5 text text-center">

    </div>
    <div class="d-flex justify-content-end">
       <a class='m-5 btn btn-primary' href="<?php echo BASE_URL . '/login'; ?>">logout</a>
    </div>
</div>

<?php require_once __DIR__ . '/../partials/js.php'; ?>
<script>
    function loadUserTask() {
        let id = <?php echo $_GET['id']; ?>;
        let callParams = {};
        callParams.url = "<?php echo route('user.load'); ?>".replace("{id}", id);
        callParams.type = 'POST';
        callParams.data = {
            "id": id,
        };
        callParams.dataType = 'JSON';
        ajaxCall(callParams, function(result) {
            $('.table tbody').html(result.data);
        }, function(err, type, httpStatus) {
            $('.table tbody').text("<tr><td colspan='6' class='text text-danger text-center'>Something went wrong!</td></tr>");
        });
        callParams.url = "<?php echo route('user.status'); ?>".replace("{id}", id);
        callParams.type = 'POST';
        callParams.data = {
            "id": id,
        };
        callParams.dataType = 'JSON';
        ajaxCall(callParams, function(result) {
            $('.status').html(result.data);
        }, function(err, type, httpStatus) {
            $('.table tbody').text("<tr><td colspan='6' class='text text-danger text-center'>Something went wrong!</td></tr>");
        });
    }
    loadUserTask();

    function updateStatus() {
        $('.message').addClass('d-none');
        $('.message .alert').removeClass('alert-success');
        $('.message .alert').removeClass('alert-danger');
        let taskId = $('[name="selectTaskId"').val();
        let status = $('[name="selectProgress"').val();
        if (!Number(taskId)) {
            $('.message').removeClass('d-none');
            $('.message .alert').addClass('alert-danger');
            $('.message .alert').html('Select an ID please');
            return;
        }
        let callParams = {};
        callParams.url = "<?php echo route('user.update'); ?>".replace("{id}", taskId);
        callParams.type = 'POST';
        callParams.data = {
            "taskId": taskId,
            "status": status,
        };
        callParams.dataType = 'JSON';
        ajaxCall(callParams, function(result) {
            if (result['status']) {
                $('.message').removeClass('d-none');
                $('.message .alert').addClass('alert-success');
                $('.message .alert').html(result['message']);
            } else {
                $('.message').removeClass('d-none');
                $('.message .alert').addClass('alert-danger');
                $('.message .alert').html(result['message']);
            }
            loadUserTask();
        }, function(err, type, httpStatus) {
            $('.message').removeClass('d-none');
            $('.message .alert').addClass('alert-danger');
            $('.message .alert').html('Something went wrong.');
        });
    }
    $(document).on('click', '#updateStatus', function(e) {
        updateStatus();
    });
</script>
<?php require_once __DIR__ . '/../partials/footer.php'; ?>