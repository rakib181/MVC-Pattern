<?php require_once __DIR__ . '/../partials/header.php'; ?>

<h1><?= $title ?></h1>

<form action="<?= BASE_URL ?>/users" method="post">
    <label for="name">Name:</label><br>
    <input type="text" id="name" name="name"><br><br>
    <label for="email">Email:</label><br>
    <input type="email" id="email" name="email"><br><br>
    <input type="submit" value="Submit">
</form>

<?php require_once __DIR__ . '/../partials/footer.php'; ?>