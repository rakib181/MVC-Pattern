<?php require_once __DIR__ . '/../partials/header.php'; ?>

<h1><?php echo $title; ?></h1>

<a href="<?php echo route('users.create'); ?>">Create User</a>

<table border="1">
    <thead>
        <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Email</th>
            <th>Actions</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach ($users as $user): ?>
            <tr>
                <td><?= $user['id'] ?></td>
                <td><?= $user['name'] ?></td>
                <td><?= $user['email'] ?></td>
                <td>
                    <a href="<?php echo route('users.edit', ['id' => $user['id']]); ?>">Edit</a>
                    <a href="<?php echo route('users.delete', ['id' => $user['id']]); ?>">Delete</a>
                </td>
            </tr>
        <?php endforeach; ?>
    </tbody>
</table>

<?php require_once __DIR__ . '/../partials/footer.php'; ?>