<?php require_once 'partials/header.php'; ?>

<h1>User Details</h1>
<p>ID: <?= $user['id'] ?></p>
<p>Name: <?= $user['name'] ?></p>
<p>Email: <?= $user['email'] ?></p>
<a href="<?= Route::route('users.index') ?>">Back to Users</a>

<?php require_once 'partials/footer.php'; ?>