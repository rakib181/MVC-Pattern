<?php require_once __DIR__ . '/../partials/header.php'; ?>

<h1><?= $title ?></h1>

<form action="<?= BASE_URL ?>/users/<?= $user['id'] ?>" method="post">
    <label for="name">Name:</label><br>
    <input type="text" id="name" name="name" value="<?= $user['name'] ?>"><br><br>
    <label for="email">Email:</label><br>
    <input type="email" id="email" name="email" value="<?= $user['email'] ?>"><br><br>
    <input type="submit" value="Update">
</form>

<?php require_once __DIR__ . '/../partials/footer.php'; ?>