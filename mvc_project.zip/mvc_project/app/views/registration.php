<?php require_once __DIR__.'/partials/header.php'; ?>
<div class="container p-5">
    <div class="message d-none">
        <div class="alert"></div>
    </div>
    <h1><?php echo $title; ?></h1>
    <form class="border p-2" id="submitBtn">
    <div class="form-group">
            <label for="name">Name : </label>
            <input type="text" class="form-control" name="name" placeholder="Enter name...">
        </div>
        <div class="form-group">
            <label for="email">Email : </label>
            <input type="text" class="form-control" name="email" placeholder="Enter email...">
        </div>
        <div class="form-group">
            <label for="password">Password : </label>
            <input type="text" class="form-control" name="password" placeholder="Enter password...">
        </div>
        <div class="form-group mt-3">
            <label for="role">Role : </label>
            <select name="role">
                <option value="user">User</option>
                <option value="admin">Admin</option>
            </select>
        </div>
        <button type="submit" class="btn btn-primary mt-3">Create</button>
        <a class="btn btn-info ms-5 mt-3" href="<?php echo BASE_URL.'/login';?>">Go to Login Page</a>
    </form>
</div>
<?php require_once __DIR__.'/partials/js.php';?>
<script>
    function createAccount(){
        $('.message').addClass('d-none');
        $('.message .alert').removeClass('alert-success');
        $('.message .alert').removeClass('alert-danger');
        let name = $('[name="name"]').val();
        let email = $('[name="email"]').val();
        let password = $('[name="password"]').val();
        let role = $('[name="role"]').val();
        let callParams = {};
        callParams.url = "<?php echo route('register.create');?>";
        callParams.type = 'POST';
        callParams.data = {
            "name" : name, 
            "email" : email,
            "password" : password,
            "role" : role,
        };
        callParams.dataType = 'JSON';
        ajaxCall(callParams, function(result){
            if(result['status']){
                $('.message').removeClass('d-none');
                $('.message .alert').addClass('alert-success');
                $('.message .alert').html(result['message']);
            }else{
                $('.message').removeClass('d-none');
                $('.message .alert').addClass('alert-danger');
                $('.message .alert').html(result['message']);
            }
        }, function(err, type, httpStatus){
                $('.message').removeClass('d-none');
                $('.message .alert').addClass('alert-danger');
                $('.message .alert').html('Something went wrong.');
        });
    }

    $(document).on('submit', '#submitBtn', function(e){
        e.preventDefault();
        createAccount();
    });
</script>
<?php require_once __DIR__ . '/partials/js.php'; ?>