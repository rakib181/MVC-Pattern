<?php require_once __DIR__ . '/../partials/header.php'; ?>

<div class="container m-5">
    <div class="message d-none">
        <div class="alert"></div>
    </div>
    <button type="submit" class="m-2 p-2 btn btn-danger"><a class="text text-white text-decoration-none" href="<?php echo BASE_URL.'/admins/dashboard'; ?>">Back</a></button>
    <h1 class="border text text-primary text-center">Assing a task to an user.</h1>
    <div class="box d-flex gap-2">
        <select name="user" class="form-select" aria-label="Default select example">
            <option value="0">Select an user</option>
            <?php
            foreach ($users as $user) {
                echo '<option value="' . $user['id'] . '">' . $user['email'] . '</option>';
            }
            ?>
        </select>
        <button id="assignBtn" class="btn btn-success">Assign</button>
    </div>
</div>

<?php require_once __DIR__ . '/../partials/js.php'; ?>
<script>
    function assignTask(){
        $('.message').addClass('d-none');
        $('.message .alert').removeClass('alert-success');
        $('.message .alert').removeClass('alert-danger');
        let userId = $('[name="user"]').val();
        let taskId = <?php echo $id;?>;
        let callParams = {};
        callParams.url = "<?php echo route('assign.task');?>";
        callParams.type = 'POST';
        callParams.data = {
            "userId" : userId,
            "taskId" :taskId,
        };
        callParams.dataType = 'JSON';
        ajaxCall(callParams, function(result){
            if(result['status']){
                $('.message').removeClass('d-none');
                $('.message .alert').addClass('alert-success');
                $('.message .alert').html(result['message']);
            }else{
                $('.message').removeClass('d-none');
                $('.message .alert').addClass('alert-danger');
                $('.message .alert').html(result['message']);
            }
        }, function(err, type, httpStatus){
            $('.message').removeClass('d-none');
            $('.message .alert').addClass('alert-danger');
            $('.message .alert').html('Something went wrong.');
        });
    }
    $(document).on('click', '#assignBtn', function(e){
        e.preventDefault();
        assignTask();
    });
</script>
<?php require_once __DIR__ . '/../partials/footer.php'; ?>