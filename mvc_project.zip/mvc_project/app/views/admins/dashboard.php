<?php require_once __DIR__.'/../partials/header.php';?>
<div class="container mt-5">
    <div class="message d-none">
        <div class="alert"></div>
    </div>
    <h1 class="text text-primary text-center border"><?php echo $title; ?></h1>
    <div class="box d-flex justify-content-end align-items-center m-2">
        <a class='btn btn-primary' href='/mvc_project/admins/taskCreate'>Create Task</a>
    </div>
    <table class="table border">
        <thead>
            <tr>
                <th scope="col">ID</th>
                <th scope="col">TITLE</th>
                <th scope="col">DESCRIPTION</th>
                <th scope="col">ASSIGNED TO</th>
                <th scope="col">DUE DATE</th>
                <th scope="col">PRIORITY</th>
                <th scope="col">STATUS</th>
            </tr>
        </thead>
        <tbody>

        </tbody>
    </table>
    <div class="d-flex justify-content-evenly mb-3">
        <a class='btn btn-info' id='reportBtn'>Report</a>
        <a class='btn btn-primary' href="<?php echo BASE_URL . '/login'; ?>">logout</a>
    </div>

    <div class="report d-flex justify-content-center">
        <div class="reportMsg d-none">
            <table class="table border">
                <thead>
                    <tr>
                        <th scope="col">ID</th>
                        <th scope="col">TITLE</th>
                        <th scope="col">DESCRIPTION</th>
                        <th scope="col">ASSIGNED TO</th>
                        <th scope="col">DUE DATE</th>
                        <th scope="col">PRIORITY</th>
                        <th scope="col">STATUS</th>
                    </tr>
                </thead>
                <tbody>

                </tbody>
            </table>
        </div>
    </div>
    <?php require_once __DIR__ . '/../partials/js.php'; ?>
    <script>
        function loadTask() {
            $('.message').addClass('d-none');
            $('.message .alert').removeClass('alert-success');
            $('.message .alert').removeClass('alert-danger');
            let callParams = {};
            callParams.url = '/mvc_project/admins/loadAllTasks';
            callParams.type = 'GET';
            callParams.data = {};
            callParams.dataType = 'JSON';
            ajaxCall(callParams, function(result) {
                $('tbody').html(result['message']);
            }, function(err, type, httpStatus) {
                $('.message').removeClass('d-none');
                $('.message .alert').addClass('alert-danger');
                $('.message .alert').html('Something went wrong.');
            });
        }
        loadTask();

        function deleteTask(id) {
            $('.message').addClass('d-none');
            $('.message .alert').removeClass('alert-success');
            $('.message .alert').removeClass('alert-danger');
            let callParams = {};
            callParams.url = "<?php echo route('task.delete') ?>".replace("{id}", id);
            callParams.type = 'POST';
            callParams.data = {
                "id": id,
            };
            callParams.dataType = 'JSON';
            ajaxCall(callParams, function(result) {
                if (result['status']) {
                    $('.message').removeClass('d-none');
                    $('.message .alert').addClass('alert-success');
                    $('.message .alert').html(result['message']);
                } else {
                    $('.message').removeClass('d-none');
                    $('.message .alert').addClass('alert-danger');
                    $('.message .alert').html(result['message']);
                }
                loadTask();
            }, function(err, type, httpStatus) {
                $('.message').removeClass('d-none');
                $('.message .alert').addClass('alert-danger');
                $('.message .alert').html('Something went wrong.');
            });
        }
        $(document).on('click', '.taskDelete', function(e) {
            e.preventDefault();
            let id = $(this).data('id');
            deleteTask(id);
        })

        function loadReport() {
            $('.reportMsg').addClass('d-none');
            let callParams = {};
            callParams.url = "<?php echo route('task.report'); ?>";
            callParams.type = 'POST';
            callParams.data = {};
            callParams.dataType = 'JSON';
            ajaxCall(callParams, function(result) {
                $('.reportMsg').removeClass('d-none');
                $('.reportMsg tbody').html(result['message']);
            }, function(err, type, httpStatus) {
                $('.reportMsg').removeClass('d-none');
                $('.reportMsg tbody').html('<tr><td>No data found.</td></tr>');
            });
        }
        $(document).on('click', '#reportBtn', function(e) {
            e.preventDefault();
            loadReport();
        })
    </script>
    <?php require_once __DIR__ . '/../partials/footer.php'; ?>