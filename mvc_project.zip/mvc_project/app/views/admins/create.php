<?php require_once __DIR__ . '/../partials/header.php'; ?>
<div class="container border mt-5">
    <div class="message d-none">
        <div class="alert"></div>
    </div>
    <button type="submit" class="m-2 p-2 btn btn-danger"><a class="text text-white text-decoration-none" href="<?php echo BASE_URL.'/admins/dashboard'; ?>">Back</a></button>
    <h1 class="text text-primary text-center border">Create a new task</h1>
    <form action="#" method="POST" class="border p-3" id="myForm">
        <div class="form-group">
            <label for="title">Title : </label>
            <input type="text" class="form-control" name="title" placeholder="Enter title">
        </div>
        <div class="form-group">
            <label for="description">Description : </label>
            <input type="text" class="form-control" name="description" placeholder="Enter description">
        </div>
        <div class="form-group">
            <label for="due_date">Due Date : </label>
            <input type="date" class="form-control" name="due_date" placeholder="Enter date">
        </div>
        <div class="form-group">
            <label for="priority">Priority : </label>
            <select type="text" class="form-control" name="priority">
                <option value="medium">medium</option>
                <option value="low">low</option>
                <option value="high">high</option>
            </select>
        </div>
        <button type="submit" class="mt-2 btn btn-primary">Create</button>
    </form>
</div>
<?php require_once __DIR__ . '/../partials/js.php' ?>
<script>
    function createTask() {
        $('.message').addClass('d-none');
        $('.message .alert').removeClass('alert-success');
        $('.message .alert').removeClass('alert-danger');
        let title = $('[name="title"]').val();
        let description = $('[name="description"]').val();
        let due_date = $('[name="due_date"]').val();
        let priority = $('[name="priority"]').val();
        let callParams = {};
        callParams.url = "<?php echo route('task.create'); ?>";
        callParams.type = 'POST';
        callParams.data = {
            "title": title,
            "description": description,
            "due_date": due_date,
            "priority": priority,
        };
        callParams.dataType = 'JSON';
        ajaxCall(callParams, function(result) {
            if (result['status']) {
                $('.message').removeClass('d-none');
                $('.message .alert').addClass('alert-success');
                $('.message .alert').html(result['message']);
            } else {
                $('.message').removeClass('d-none');
                $('.message .alert').addClass('alert-danger');
                $('.message .alert').html(result['message']);
            }
        }, function(err, type, httpStatus) {
            $('.message').removeClass('d-none');
            $('.message .alert').addClass('alert-danger');
            $('.message .alert').html('Something went wrong.');
        });
    }
    $(document).on('submit', '#myForm', function(e) {
        e.preventDefault();
        createTask();
    })
</script>
<?php require_once __DIR__ . '/../partials/footer.php' ?>