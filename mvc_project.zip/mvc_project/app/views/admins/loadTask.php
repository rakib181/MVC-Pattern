<form action="#" method="POST" class="border p-3" id="myForm">
        <div class="form-group">
            <label for="title">Title : </label>
            <input type="text" class="form-control" name="title" value="<?php echo $task['title'];?>">
        </div>
        <div class="form-group">
            <label for="description">Description : </label>
            <input type="text" class="form-control" name="description" value="<?php echo $task['description'];?>">
        </div>
        <div class="form-group">
            <label for="due_date">Due Date : </label>
            <input type="date" class="form-control" name="due_date" value="<?php echo $task['due_date'];?>">
        </div>
        <div class="form-group">
            <label for="priority">Priority : </label>
            <select type="text" class="form-control" name="priority">
                <option value="medium" <?php echo ($task['priority'] === 'medium') ? 'selected' : ''; ?>>medium</option>
                <option value="low" <?php echo ($task['priority'] === 'low') ? 'selected' : ''; ?>>low</option>
                <option value="high" <?php echo ($task['priority'] === 'high') ? 'selected' : ''; ?>>high</option>
            </select>
        </div>
        <button type="submit" class="mt-2 btn btn-primary">Update</button>
    </form>