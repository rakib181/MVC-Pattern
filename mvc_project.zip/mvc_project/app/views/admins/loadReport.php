<?php
foreach($tasks as $task): ?>
    <tr>
        <td><?php echo $task['id']?></td>
        <td><?php echo $task['title']?></td>
        <td><?php echo $task['description']?></td>
        <td><?php echo $task['assigned_to']?></td>
        <td><?php echo $task['due_date']?></td>
        <td><?php echo $task['priority']?></td>
        <td><?php echo $task['status']?></td>
    </tr>
<?php endforeach; ?>