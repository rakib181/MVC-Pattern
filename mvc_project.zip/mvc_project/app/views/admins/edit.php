<?php require_once __DIR__ . '/../partials/header.php'; ?>
<div class="container border mt-5">
    <div class="message d-none">
        <div class="alert"></div>
    </div>
    <button type="submit" class="m-2 p-2 btn btn-danger"><a class="text text-white text-decoration-none" href="<?php echo BASE_URL.'/admins/dashboard'; ?>">Back</a></button>
    <h1 class="text text-primary text-center border">Edit task</h1>
    <div class="myFormData">

    </div>
</div>
<?php require_once __DIR__ . '/../partials/js.php' ?>
<script>
    function loadTask(){
        let taskId = <?php echo $id;?>;
        let callParams = {};
        callParams.url = "/mvc_project/admins/loadTask";
        callParams.type = 'GET';
        callParams.data = {
            "id": taskId,
        };
        callParams.dataType = 'JSON';
        ajaxCall(callParams, function(result){
           $('.myFormData').html(result['message']);
        }, function(err, type, httpStatus){
            $('.message').removeClass('d-none');
            $('.message .alert').addClass('alert-danger');
            $('.message .alert').html('Something went wrong.');
        });
    }
    loadTask();
    function updateTask(){
        let taskId = <?php echo $id;?>;
        let title = $('[name="title"]').val();
        let description = $('[name="description"]').val();
        let due_date = $('[name="due_date"]').val();
        let priority = $('[name="priority"]').val();
        let callParams = {};
        callParams.url = "<?php echo route('task.edit');?>";
        callParams.type = 'POST';
        callParams.data = {
            "id" : taskId,
            "title": title,
            "description": description,
            "due_date": due_date,
            "priority": priority,
        };
        callParams.dataType = 'JSON';
        ajaxCall(callParams, function(result) {
            if (result['status']) {
                $('.message').removeClass('d-none');
                $('.message .alert').addClass('alert-success');
                $('.message .alert').html(result['message']);
            } else {
                $('.message').removeClass('d-none');
                $('.message .alert').addClass('alert-danger');
                $('.message .alert').html(result['message']);
            }
            loadTask();
        }, function(err, type, httpStatus) {
            $('.message').removeClass('d-none');
            $('.message .alert').addClass('alert-danger');
            $('.message .alert').html('Something went wrong.');
        });
    }
    $(document).on('submit', '#myForm', function(e){
        e.preventDefault();
        updateTask();
    });
</script>
<?php require_once __DIR__ . '/../partials/footer.php' ?>