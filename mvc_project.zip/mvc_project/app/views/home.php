<?php require_once __DIR__ . '/partials/header.php'; ?>

<h1><?php echo $title; ?></h1>
<p>Welcome to the home page!</p>

<?php require_once __DIR__ . '/partials/footer.php'; ?>