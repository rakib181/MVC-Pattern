<?php require_once __DIR__ . '/partials/header.php'; ?>
<div class="container p-5">
    <div class="message d-none">
        <div class="alert"></div>
    </div>
    <h1><?php echo $title; ?></h1>
    <form class="border p-2" id="submitBtn">
        <div class="form-group">
            <label for="email">Email : </label>
            <input type="text" class="form-control" name="email" placeholder="Enter email...">
        </div>
        <div class="form-group">
            <label for="password">Password : </label>
            <input type="text" class="form-control" name="password" placeholder="Enter password...">
        </div>
        <button type="submit" class="btn btn-primary mt-2">Submit</button>
        <a class="btn btn-info ms-5 mt-2" href="<?php echo BASE_URL.'/register';?>">Sign-Up</a>
    </form>
</div>
<?php require_once __DIR__ . '/partials/js.php'; ?>
<script>
    function login() {
        $('.message').addClass('d-none');
            $('.message .alert').removeClass('alert-success');
            $('.message .alert').removeClass('alert-danger');
        let email = $('[name="email"]').val();
        let password = $('[name="password"]').val();
        let callParams = {};
        callParams.url = "<?php echo route('login.cred'); ?>";
        callParams.type = 'POST';
        callParams.data = {
            "email": email,
            "password": password,
        };
        callParams.dataType = 'JSON';
        ajaxCall(callParams, function(result) {
            if(result['status']){
               let role = result['message']['role'];
               let id = result['message']['id'];
               if(role === "admin"){
                 window.location.href = `<?php echo BASE_URL.'/admins/dashboard';?>?id=${id}`;
               }else{
                 window.location.href = `<?php echo BASE_URL.'/users/dashboard';?>?id=${id}`;
               }
            }else{
                $('.message').removeClass('d-none');
                $('.message .alert').addClass('alert-danger');
                $('.message .alert').html('Invalid Email or Password.');
            }
        }, function(err, type, httpStatus) {
                $('.message').removeClass('d-none');
                $('.message .alert').addClass('alert-danger');
                $('.message .alert').html('Something went wrong.');
        });
    }
    $(document).on('submit', '#submitBtn', function(e) {
        e.preventDefault();
        login();
    });
</script>
<?php require_once __DIR__ . '/partials/footer.php'; ?>