<?php

class Router {
    protected $routes = [];
    protected $namedRoutes = [];
    protected $params = [];

    public function add($route, $params = [], $method = 'GET', $name = null) {
        $this->routes[$method][$route] = $params;

        if ($name !== null) {
            $this->namedRoutes[$name] = ['route' => $route, 'method' => $method];
        }

        return $this;
    }

    public function name($name) {
        $lastMethod = array_key_last($this->routes);
        $lastRoute = array_key_last($this->routes[$lastMethod]);

        if ($lastRoute !== null) {
            $this->namedRoutes[$name] = ['route' => $lastRoute, 'method' => $lastMethod];
        }
        return $this;
    }

    public function dispatch() {
        $url          = $this->getUrl();
        $method       = $_SERVER['REQUEST_METHOD'];
        $this->params = [];

        if (isset($this->routes[$method]) && array_key_exists($url, $this->routes[$method])) {
            $this->params = $this->routes[$method][$url];
            $this->callAction($this->params);
            return;
        } else {
            if (isset($this->routes[$method])) {
                foreach ($this->routes[$method] as $route => $params) {
                    if (strpos($route, '{') !== false) {
                        $routeRegex = preg_replace('/\{([a-zA-Z0-9_]+)\}/', '([a-zA-Z0-9_]+)', $route);
                        $routeRegex = str_replace('/', '\/', $routeRegex);
                        if (preg_match('/^' . $routeRegex . '$/', $url, $matches)) {
                            array_shift($matches);
                            $this->params = $params;
                            $this->params['matches'] = $matches;
                            $this->callAction($this->params);
                            return;
                        }
                    }
                }
            }
        }
        echo "404 Not Found";
    }

    protected function getUrl() {
        if (isset($_GET['url'])) {
            return $_GET['url'];
        }
        return '';
    }

    protected function callAction($params) {
        if (is_array($params['action'])) {
            $controller = $params['action'][0];
            $method = $params['action'][1];
            $controller = new $controller();
            if (method_exists($controller, $method)) {
                call_user_func_array([$controller, $method], isset($params['matches']) ? $params['matches'] : []);
            } else {
                echo "Method not found";
            }
        } else {
            echo "Invalid route action";
        }
    }

    public static function get($route, $action) {
        global $router;
        return $router->add($route, ['action' => $action], 'GET');
    }

    public static function post($route, $action) {
        global $router;
        return $router->add($route, ['action' => $action], 'POST');
    }

    public static function put($route, $action) {
        global $router;
        return $router->add($route, ['action' => $action], 'PUT');
    }

    public static function delete($route, $action) {
        global $router;
        return $router->add($route, ['action' => $action], 'DELETE');
    }

    public function getRouteByName($name, $params = []) {
        if (isset($this->namedRoutes[$name])) {
            $routeData = $this->namedRoutes[$name];
            $route = $routeData['route'];
            if (!empty($params)) {
                foreach ($params as $key => $value) {
                    $route = str_replace('{' . $key . '}', $value, $route);
                }
            }
            return BASE_URL . $route;
        }
        return null;
    }

    public function getRouteDataByNameOrRoute($nameOrRoute) {
        foreach ($this->routes as $method => $routes) {
            foreach ($routes as $route => $params) {
                if ($route === $nameOrRoute) {
                    return ['route' => $route, 'method' => $method];
                }
            }
        }
        if (isset($this->namedRoutes[$nameOrRoute])){
            return $this->namedRoutes[$nameOrRoute];
        }
        return null;
    }
}