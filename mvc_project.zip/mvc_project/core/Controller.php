<?php

namespace Core;

class Controller {
    public function view($view, $data = [], $return = false) {
        extract($data);
        ob_start(); // Start output buffering
        require_once __DIR__ . '/../app/views/' . $view . '.php';
        $content = ob_get_clean(); // Get and clean buffer
        if ($return) {
            return $content;
        } else {
            echo $content;
        }
    }
}